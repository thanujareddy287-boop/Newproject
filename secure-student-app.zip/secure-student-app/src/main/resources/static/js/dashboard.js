async function csrf() {
    await fetch("/api/auth/csrf", { credentials: "same-origin" });
}

function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(";").shift();
    return "";
}

function safeText(value) {
    return document.createTextNode(String(value ?? ""));
}

async function loadUser() {
    const response = await fetch("/api/auth/me", { credentials: "same-origin" });

    if (!response.ok) {
        window.location.href = "/login.html";
        return null;
    }

    const user = await response.json();
    document.getElementById("userInfo").textContent =
        `Logged in as ${user.name} (${user.role})`;

    if (user.role === "ADMIN") {
        document.getElementById("adminPanel").hidden = false;
    }

    return user;
}

async function loadStudents(user) {
    const response = await fetch("/api/students", {
        credentials: "same-origin"
    });

    if (!response.ok) {
        document.getElementById("message").textContent = "Could not load students";
        return;
    }

    const students = await response.json();
    const tbody = document.getElementById("students");
    tbody.replaceChildren();

    for (const student of students) {
        const row = document.createElement("tr");

        for (const value of [student.id, student.name, student.email, student.course]) {
            const cell = document.createElement("td");
            cell.appendChild(safeText(value));
            row.appendChild(cell);
        }

        const actionCell = document.createElement("td");

        if (user.role === "ADMIN") {
            const button = document.createElement("button");
            button.textContent = "Delete";
            button.addEventListener("click", () => deleteStudent(student.id));
            actionCell.appendChild(button);
        } else {
            actionCell.appendChild(safeText("Read only"));
        }

        row.appendChild(actionCell);
        tbody.appendChild(row);
    }
}

async function deleteStudent(id) {
    await csrf();

    const response = await fetch(`/api/students/${id}`, {
        method: "DELETE",
        credentials: "same-origin",
        headers: {
            "X-XSRF-TOKEN": getCookie("XSRF-TOKEN")
        }
    });

    if (response.ok) {
        const user = await loadUser();
        await loadStudents(user);
    } else {
        const data = await response.json().catch(() => ({}));
        document.getElementById("message").textContent =
            data.error || "Delete failed";
    }
}

document.getElementById("studentForm")?.addEventListener("submit", async (event) => {
    event.preventDefault();
    await csrf();

    const response = await fetch("/api/students", {
        method: "POST",
        credentials: "same-origin",
        headers: {
            "Content-Type": "application/json",
            "X-XSRF-TOKEN": getCookie("XSRF-TOKEN")
        },
        body: JSON.stringify({
            name: document.getElementById("studentName").value,
            email: document.getElementById("studentEmail").value,
            course: document.getElementById("studentCourse").value
        })
    });

    if (response.ok) {
        event.target.reset();
        const user = await loadUser();
        await loadStudents(user);
    } else {
        const data = await response.json().catch(() => ({}));
        document.getElementById("message").textContent =
            data.error || "Could not add student";
    }
});

document.getElementById("logout").addEventListener("click", async () => {
    await csrf();

    await fetch("/api/auth/logout", {
        method: "POST",
        credentials: "same-origin",
        headers: {
            "X-XSRF-TOKEN": getCookie("XSRF-TOKEN")
        }
    });

    window.location.href = "/login.html";
});

(async () => {
    const user = await loadUser();
    if (user) await loadStudents(user);
})();
